create view adminticketview as
select `trafficticket`.`ticketinfo`.`driverId` AS `driverId`,
       `trafficticket`.`ticketinfo`.`carId`    AS `carId`,
       `trafficticket`.`ticketinfo`.`policeId` AS `policeId`
from `trafficticket`.`ticketinfo`;

