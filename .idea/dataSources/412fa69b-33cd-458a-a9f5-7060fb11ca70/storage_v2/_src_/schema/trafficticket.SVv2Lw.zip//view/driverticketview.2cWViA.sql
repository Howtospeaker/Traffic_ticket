create view driverticketview as
select `trafficticket`.`ticketinfo`.`driverId` AS `driverId`, `trafficticket`.`ticketinfo`.`carId` AS `carId`
from `trafficticket`.`ticketinfo`;

